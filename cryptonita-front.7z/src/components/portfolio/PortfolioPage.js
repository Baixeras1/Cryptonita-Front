import React from "react";
import Portfolio from "./Portfolio"

function PortfolioPage() {
    return (
      <>
        <Portfolio />
      </>
    );
  }
  
  export default PortfolioPage;
  