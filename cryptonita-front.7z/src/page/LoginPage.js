import SignUp from "./components/Login";

function LoginPage() {
  return <SignUp></SignUp>;
}
export default LoginPage;
